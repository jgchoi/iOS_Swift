//
//  CoursesInProgramList.swift
//  Use WS v1
//
//  Created by Peter McIntyre on 2016-04-07.
//  Copyright © 2016 School of ICT, Seneca College. All rights reserved.
//

import UIKit
import CoreData

class CoursesInProgramList: UITableViewController {

    // MARK: - Private properties
    
    var frc: NSFetchedResultsController!
    var arr = [AnyObject]()
    
    // Data object, passed in by the parent view controller in the segue method
    var programCode: String!

    // MARK: - Properties
    
    // Passed in by the app delegate during app initialization
    var model: Model!

    // MARK: - View lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Increase the table cell height
        tableView.rowHeight = 55.0

        // Add a listener (observer) for the 'fetch completed' event
        // The name format is: <CallingClassName>_<property>_fetch_completed
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(self.coursesGet), name: "Model_courses_fetch_completed", object: nil)

        // Set the value of the local property (which forces the web service request to execute)
        // The Model object will immediately return an empty array, but its code will execute the web service request, and wait for the response
        arr = model.coursesGet(programCode)
    }

    func coursesGet() {
        
        // This method is called when there's new/updated data from the network
        
        arr = model.courses
        tableView.reloadData()
    }

    // MARK: - Table view methods

    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {

        return 1
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return arr.count
    }

    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCellWithIdentifier("cell", forIndexPath: indexPath) as UITableViewCell
        
        self.configureCell(cell, atIndexPath: indexPath)
        
        return cell
    }
    
    func configureCell(cell: UITableViewCell, atIndexPath indexPath: NSIndexPath) {
        
        // Get a reference to an object in the collection
        let item: AnyObject = arr[indexPath.row]
        
        cell.textLabel!.text = item.valueForKey("Code") as? String
        
        cell.detailTextLabel!.text = item.valueForKey("Name") as? String
    }

}
