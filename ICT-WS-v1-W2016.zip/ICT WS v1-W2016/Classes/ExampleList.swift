//
//  ExampleList.swift
//  Classes
//
//  Created by Peter McIntyre on 2015-02-01.
//  Copyright (c) 2015 School of ICT, Seneca College. All rights reserved.
//

import UIKit
import CoreData

// Notice the protocol conformance
class ExampleList: UITableViewController, NSFetchedResultsControllerDelegate {

    // MARK: - Private properties
    
    var frc: NSFetchedResultsController!
    var arr = [AnyObject]()
    
    // MARK: - Properties

    // Passed in by the app delegate during app initialization
    var model: Model!
    
    // MARK: - View lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Increase the table cell height
        tableView.rowHeight = 55.0
        
        // Add a listener (observer) for the 'fetch completed' event
        // The name format is: <CallingClassName>_<property>_fetch_completed
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(self.programsGet), name: "Model_programs_fetch_completed", object: nil)
        
        // Set the value of the local property (which forces the web service request to execute)
        // The Model object will immediately return an empty array, but its code will execute the web service request, and wait for the response
        arr = model.programsGet()
        
        // The frc is NOT used in this code example
        // The data for the table view comes from a web service call, and is in the "arr" array
        
        // Configure and load the fetched results controller (frc)
        frc = model.frc_example

        // This controller will be the frc delegate
        frc.delegate = self;
        // No predicate (which means the results will NOT be filtered)
        frc.fetchRequest.predicate = nil;
        
        // Create an error object
        var error: NSError? = nil
        // Perform fetch, and if there's an error, log it
        do {
            try frc.performFetch()
        } catch let error1 as NSError { error = error1; print(error?.description) }
    }

    func programsGet() {
        
        // This method is called when there's new/updated data from the network
        //println("Get all:\n\(model.programs.description)")
        
        arr = model.programs
        tableView.reloadData()
    }
    
    // MARK: - Table view methods

    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        
        return 1
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return arr.count
    }

    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCellWithIdentifier("cell", forIndexPath: indexPath) as UITableViewCell

        self.configureCell(cell, atIndexPath: indexPath)

        return cell
    }

    func configureCell(cell: UITableViewCell, atIndexPath indexPath: NSIndexPath) {
        
        // Get a reference to an object in the collection
        let item: AnyObject = arr[indexPath.row]

        cell.textLabel!.text = item.valueForKey("Code") as? String
        
        cell.detailTextLabel!.text = item.valueForKey("Name") as? String
    }
    
    // MARK: - Navigation

    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        // The "toExampleDetail" segue is not usable in this code example
        // It was originally used, before the course list was coded
        // It could be put back into service, for a "detail disclosure" view
        
        if segue.identifier == "toExampleDetail" {

            // Get a reference to the destination view controller
            let vc = segue.destinationViewController as! ExampleDetail
            
            // From the data source (the fetched results controller)...
            // Get a reference to the object for the tapped/selected table view row
            let item: AnyObject = arr[self.tableView.indexPathForSelectedRow!.row]
            
            // Pass on the object
            vc.detailItem = item
            
            // Configure the view if you wish
            vc.title = item.valueForKey("Code") as? String
        }
        
        if segue.identifier == "toCourseList" {
            
            // Get a reference to the destination view controller
            let vc = segue.destinationViewController as! CoursesInProgramList
            
            // From the data source (the fetched results controller)...
            // Get a reference to the object for the tapped/selected table view row
            let item: AnyObject = arr[self.tableView.indexPathForSelectedRow!.row]
            
            // Pass on a reference to the model
            vc.model = model
            
            // Pass on the object
            vc.programCode = item.valueForKey("Code") as? String
            
            // Configure the view if you wish
            vc.title = (item.valueForKey("Code") as? String)! + " courses"
        }
    }

}
