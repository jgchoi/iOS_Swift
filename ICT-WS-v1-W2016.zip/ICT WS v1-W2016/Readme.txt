
This is Readme.txt

This app shows lists of academic programs and courses in the School of ICT.

The data for the lists is delivered by a public web service.

The first scene shows a list of academic programs (e.g. BSD, CPA). It appears as a result of a web service call.

When a program is tapped/selected, its course code is used to make another web service call.

Please note that courses are available only for the BSD and CPA programs (and not for the others).
