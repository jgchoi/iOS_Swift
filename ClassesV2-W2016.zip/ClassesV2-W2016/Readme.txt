
This is Readme.txt

You can use this project as a 'template'. How?

In Finder, select this project's folder.
Command+D to duplicate.

Rename the folder to your desired new name.
Open the folder, then open the project file (still named "Classes.xcodeproj") in Xcode.

In the Project Navigator, select the project item (it has a blue icon).
Press the tab key, and type your desired new name.
You will be prompted through the rename procedure.

On the Product menu, choose Scheme > Manage Schemes...
Click to select the (only) scheme, and press the tab key until it highlights the (old) scheme name.
Type the new scheme name, and press Enter (then Close on the dialog box)

~~~~~~~~~~

This is a beta version of ClassesV2.

It has a 'web service request' class, and a model class with example 'collection' and 'item' property + requester pairs.
