//
//  ViewController.swift
//
//  Created by Danny Abesdris on 2016-02-10.
//  Copyright © 2016 Danny Abesdris. All rights reserved.
//

// Modified ViewController.swift that adds private methods and allows
// table indexing by section.

import UIKit
// The "MARK :" "comments" (actually preprocessor features) below are used to organize and document
// your code.
// These preprocessor features allow you to bring some structure to the function drop
// down box of the source code editor.

// MARK:
// MARK: Connecting Data Source and Delegate
/* A table view is supposed to have a data source and a delegate.
   The data source and delegate objects of the table view need to conform to the
   UITableViewDataSource and UITableViewDelegate protocol respectively.
   Protocols are listed after the superclass of the class, and multiple protocols are
   separated by commas (see line 23 below)
*/
class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

   var langs: [String] = [ ]                      // an array of String objects
   let cellIdentifier = "CellIdentifier"          // identifier of prototype cell
   var alphabetizedLangs = [String: [String]]( )  // a dictionary of String arrays
                                                  // (i.e. key=String, value=[String])
   
   override func viewDidLoad( ) {
   
      /* The UIViewController class, the superclass of the ViewController class,
         also defines a viewDidLoad( ) method. The ViewController class overrides the viewDidLoad( )
         method defined by the UIViewController class. This is indicated by the override keyword.
         In order to ensure that the base class viewDidLoad( ) method is invoked, the super keyword
         is used to call the super class's viewDidLoad( ) method.
      */

      super.viewDidLoad( )
      
      // initializing the "langs" array with hardcoded data
      langs = [ "C", "Perl", "Python", "C++", "Java", "Pascal", "Ruby", "Swift", "Javascript",
                "PHP", "Assembler", "Processing.js", "Prolog", "Smalltalk", "Objective-C", "C#", "PL/SQL",
                "Rust", "Basic", "Logo", "Lisp", "D", "Simula", "Haskell", "Go", "Fortran", "Erlang",
                "Ada", "Bash", "Algol 68", "AppleScript", "ActionScript", "COBOL", "Delphi"]
      
      // calling the private alphabetize( ) function to sort the array "langs" and
      // return a dictionary consisting of keys of uppercase letters with their
      // corresponding languages (i.e. A=>"Algol 68", AppleScript"; P="PHP, Prolog, Python", etc)
      
      alphabetizedLangs = alphabetize(langs)
      
      // Do any additional setup after loading the view, typically from a nib.
   }

   // Private utility function used to return the keys in the alphabetized languages property.
   // Sort keys in the dictionary alphabetically (keys are: A, B, C, D, etc.)
   private func getLangKeys( ) -> [String] {
      return alphabetizedLangs.keys.sort({ (a, b) -> Bool in a.lowercaseString < b.lowercaseString })
   }

   // Private utility function used to sort and return a dictionary containing an array
   // of Strings where each dictionary key is an alphabetic character and each dictionary
   // value is an array of languages beginning with that letter.
   private func alphabetize(array: [String]) -> [String: [String]] {
      var result = [String: [String]]( )
     
      for item in array {
         let index = item.startIndex.advancedBy(1)
         let firstLetter = item.substringToIndex(index).uppercaseString
         
         if result[firstLetter] != nil {
            result[firstLetter]!.append(item)
         }
         else {
            result[firstLetter] = [item]
         }
      }
     
      for (key, value) in result {
         result[key] = value.sort({ (a, b) -> Bool in a.lowercaseString < b.lowercaseString })
      }
      return result
   }

   override func didReceiveMemoryWarning() {
      super.didReceiveMemoryWarning()
      // Dispose of any resources that can be recreated.
   }
   
   // MARK: -
   // MARK: Table View Data Source Protocol Methods
   /*
      Because the view controller was used as the data source object of the table view, the table
      view gets its data from the view controller. The first piece of information the table view
      requires from its data source is the number of sections it should display.
      The table view does this by invoking the numberOfSectionsInTableView(_:) method on its data source.
      This is an optional method of the UITableViewDataSource protocol. If the table view's data source
      doesn't implement this method, the table view assumes that it needs to display only one section.
      But, "what is a table view section?" A table view section is a group of rows (which can be grouped
      by the first letter of name in each row for example).

      The numberOfSectionsInTableView(_:) method accepts one argument, tableView, which is the table view
      that sent the message to the data source object. This is important, because it allows the data source
      object to be the data source of multiple table views if necessary.
      In the code below, the numberOfSectionsInTableView(_:) method returns an alphabetical order
      of keys in the alphabetizedLangs dictionary which consists of the capital letter of each
      group of languages beginning with that letter.
   */
   func numberOfSectionsInTableView(tableView: UITableView) -> Int {
      let keys = alphabetizedLangs.keys
      return keys.count
   }
   
   
   /*
      Now that the table view knows how many sections it needs to display, it asks its data source how
      many rows each section contains. For each section in the table view, the table view sends the data
      source a message of tableView(_:numberOfRowsInSection:). This method accepts two arguments, the table
      view sending the message and the table view's section index containing its specific number of rows.

      numberOfSectionsInTableView(_:) returns the number of languages contained in each section where
      each section is delimited by an alphabetic key ('A', 'B', 'P', etc.).
      NOTE: This first required sorting the dictionary keys which was accomplised by the private
            utility function getLangKeys( ).
            Sorting the array of keys is important, because the key-value pairs of a dictionary are
            unordered. This is a key difference between arrays and dictionaries and a concept that often
            overlooked or misunderstood.
   */
   func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
   
      // Calling private utility function to get the array of [String] keys in the dictionary
      let sortedLangKeys = getLangKeys( )
     
      // This now sets "key" to the array of Strings in each dictionary key
      // (i.e. A=>"Algol 68", AppleScript" OR P=>"PHP, Prolog, Python", etc.)
      let key = sortedLangKeys[section]
     
      // Return the number of languages in each "section".
      return alphabetizedLangs[key] != nil ? alphabetizedLangs[key]!.count : 0
   }
   
   /*
      The next method required to ensure that the ViewController class conforms to the UITableViewDataSource
      protocol is tableView(_:cellForRowAtIndexPath:). The table view expects the data source, the
      ViewController instance, to return a table view cell for each row in the table view.
      The tableView(_:cellForRowAtIndexPath:) method sends a message to its data source and asks it for
      the table view cell of the row specified by indexPath, the second argument of the method.
      
      NOTE: This method contains an instance of the NSIndexPath class. The NSIndexPath class represents the
      path to a specific node in a tree of nested array collections. An instance of this class can hold one
      or more indices. In the case of a table view, it holds an index for the section an item is in and the
      row of that item in the section.
      A table view is never more than two levels deep, the first level being the section and the second level
      being the row in the section.
   */
   func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
      let cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier, forIndexPath: indexPath)
     
      // Get and sort the keys
      let keys = getLangKeys( )
     
      // Capture languages for section at indexPath
      let key = keys[indexPath.section]
     
      if let langs = alphabetizedLangs[key] {
         // Get language
         let sectionLang = langs[indexPath.row]
         
         // Configure Cell in TableView
         /*
            The text of the textLabel property of the table view cell can now be set to
            the language at a specific row within each section. The UITableViewCell class is a
            UIView subclass and it has a number of subviews. One of these subviews is an instance of
            UILabel which is used to display the name of the programming language in the table view cell.
         */
         cell.textLabel?.text = sectionLang
      }
      return cell
   }
   
   /*
      To add sections to the Table View, the tableView(_: UITableView, titleForHeaderInSection section: Int)
      UITableViewDataSource protocol must be implemented. Sections are based on the first letter of each
      proramming language.
      To add sections to the table view, an array of names is not sufficient. Instead, the data needs to be
      broken up into sections with the languages in each section sorted alphabetically. This method
      requires a dictionary of type: [String: [String]] which was declared in the ViewController class
      as: var alphabetizedLangs = [String: [String]]( )
      In viewDidLoad( ), the "langs" array is used to create a dictionary of languages. The dictionary
      contains an array of programming languages for each letter of the alphabet. For letters without
      a language, that key is omitted from the dictionary.
      The dictionary is created with the help of a helper method, alphabetize(_:) which accepts the
      "langs" array as an argument.
      
      In order to tell the table view that it should display a letter in each section header, the
      tableView(_:titleForHeaderInSection:), method that is defined in the UITableViewDataSource protocol
      is now implemented. Note how it is similar to the implementation of the tableView(_:numberOfRowsInSection:)
      method in that it simply returns the number of keys in each sectionby first calling the private
      utility method getLangKeys( ) which returns a sorted array of keys in the dictionary.
   */
   func tableView(tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
      // Get and sort keys
      var keys = getLangKeys( )
      /* 
      for i in 0..<keys.count {
         keys[i] += " section..."
      }
      */
      return keys[section]
   }
   
   /*
      Delegation:
      In addition to the UITableViewDataSource protocol, the UIKit framework also defines the UITableViewDelegate
      protocol, the protocol to which the table view's delegate needs to conform.
      This was accomplished on the storyboard by setting the view controller as the delegate of the table view.

      To implemet a method that respond to touch events (for example, whenever a user touches a row),
      tableView(_:didSelectRowAtIndexPath:) is implemented and simply displays the text of each programming
      language on the console.
      This is used to demonstrate how the delegate pattern works.
   */
   
   // MARK: -
   // MARK: Table View Delegate Methods
   func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
      // Get and sort keys
      let keys = getLangKeys( )
     
      // Capture languages for section at indexPath
      let key = keys[indexPath.section]
          
      if let langs = alphabetizedLangs[key] {
         print(langs[indexPath.row]) // display the language for the specific row selected at
                                     // the specific section
      }
   }
}
