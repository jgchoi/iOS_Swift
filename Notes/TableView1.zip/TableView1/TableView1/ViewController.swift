//
//  ViewController.swift
//  TableView1
//
//  Created by Danny Abesdris on 2016-02-10.
//  Copyright © 2016 Danny Abesdris. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
   var langs: [String] = [ ]
   let cellIdentifier = "CellIdentifier"
   
   override func viewDidLoad( ) {
      super.viewDidLoad( )
      
      langs = [ "C", "Perl", "Python", "C++", "Java", "Pascal", "Ruby", "Swift", "Javascript",
              "PHP", "Assembler", "Processing.js", "Prolog", "Smalltalk", "Objective-C", "C#",
              "PL/SQL", "Rust", "Basic", "Logo", "Lisp", "D", "Simula", "Haskell", "Go",
              "Fortran", "Erlang", "Ada", "Bash", "Algol 68", "AppleScript", "ActionScript",
              "COBOL", "Delphi"]
      // Do any additional setup after loading the view, typically from a nib.
   }

   override func didReceiveMemoryWarning() {
      super.didReceiveMemoryWarning()
      // Dispose of any resources that can be recreated.
   }

   func numberOfSectionsInTableView(tableView: UITableView) -> Int {
       return 1
   }
   func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
      return langs.count
   }
   func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
      let cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier, forIndexPath: indexPath)
     
      let myLang = langs[indexPath.row]
     
      cell.textLabel?.text = myLang
      return cell
   }
   func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
      print(langs[indexPath.row])
   }
}

