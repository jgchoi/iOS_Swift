
This is Readme.txt

This project is based on the professor's version of the "Canada" app.

It includes support for the 'add item' pattern. Important features of this pattern:

1. 'Add item' scene will be presented modally, and is embedded in a nav controller.

2. The 'add item' controller source code file includes a protocol declaration, with one method.

3. The 'add item' controller declares a delegate property (which will point to the presenting controller).

4. The presenting controller will conform to the protocol, and therefore implement the protocol's declared method. The method will do what it has to do to save/store the new item.

5. It will also include code to segue to this controller. Its scene needs a suitable (nav) bar button.

If you did your job in Lab 4, these are the only changes you must make. 
